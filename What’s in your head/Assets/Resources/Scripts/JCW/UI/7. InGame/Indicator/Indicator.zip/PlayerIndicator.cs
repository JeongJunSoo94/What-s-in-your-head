using Photon.Pun;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using YC.CameraManager_;

namespace JCW.UI.InGame.Indicator
{
    [RequireComponent(typeof(PhotonView))]
    public class PlayerIndicator : BaseIndicator
    {
        Transform target;
        [Header("ž���� ���� �ڶ�/���׵� ��������Ʈ")] [SerializeField] Sprite nellaTopView;
                                                [SerializeField] Sprite steadyTopView;
        [Header("������ �ڶ�/���׵� ��������Ʈ")] [SerializeField] Sprite nellaNormal;
                                                [SerializeField] Sprite steadyNormal;

        //ž���� ���� �ڱ� UI
        Sprite myIndicatorTop;
        //���� UI
        Sprite otherIndicatorTop;
        Sprite otherIndicatorNormal;

        //�� �̹��� & ���� �̹���
        RectTransform myImgTransform;
        // �� �÷��̾� ��ġ
        Transform myTF;

        PhotonView photonView;

        Image myImg;
        Image otherImg;

        protected void Awake()
        {            
            photonView = GetComponent<PhotonView>();
            if (!photonView.IsMine)
            {
                Destroy(this.gameObject);
                return;
            }            
            // �������� ����� ���� �Ʒ� �ڵ� ����
            isNella = GameManager.Instance.characterOwner[PhotonNetwork.IsMasterClient];
            if(isNella)
            {
                myIndicatorTop = nellaTopView;
                otherIndicatorTop = steadyTopView;
                otherIndicatorNormal = steadyNormal;
            }
            else
            {
                myIndicatorTop = steadyTopView;
                otherIndicatorTop = nellaTopView;
                otherIndicatorNormal = nellaNormal;
            }

            // �ӽ�
            //isNella = true;
            detectUI = transform.GetChild(0).gameObject;
            myImgTransform = detectUI.transform.GetChild(0).GetComponent<RectTransform>();
            myImgTransform.sizeDelta = new Vector2(myIndicatorTop.bounds.size.x, myIndicatorTop.bounds.size.y);
            imgTransform = detectUI.transform.GetChild(1).GetComponent<RectTransform>();

            myImg = myImgTransform.gameObject.GetComponent<Image>();
            myImg.sprite = myIndicatorTop;

            //TopView������ �޾ƿ;���            

            // ��� ���϶��� ���� =======================================================================================
            // ������ ������ ��������Ʈ ũ�⸸ŭ ���� ����
            imgTransform.sizeDelta = new Vector2(otherIndicatorNormal.bounds.size.x, otherIndicatorNormal.bounds.size.y);
            otherImg = imgTransform.gameObject.GetComponent<Image>();
            otherImg.sprite = otherIndicatorNormal;

            canvasSize = detectUI.GetComponent<RectTransform>();
            screenLimitOffset = imgTransform.rect.width * 0.4f;
            outOfSightImgScale = imgTransform.localScale * 0.8f;
            initImgScale = imgTransform.localScale;
            // ========================================================================================================

            

            //Ÿ���� ����
            //target = GameManager.Instance.otherPlayerTF;            
            myTF = transform.parent;

            // �� ī�޶� �����;���
            //mainCamera = isNella ? CameraManager.Instance.cameras[0] : CameraManager.Instance.cameras[1];
            SetSreenInfo();
        }

        void Update()
        {
            if (mainCamera == null)
                SetCam();
            // Ÿ���� ��ġ�� ����ī�޶��� ��ũ�� ��ǥ�� ����
            Vector3 indicatorPosition = mainCamera.WorldToScreenPoint(GameManager.Instance.otherPlayerTF.position);
            if (!GameManager.Instance.isTopView)
            {               
                otherImg.sprite = otherIndicatorNormal;

                // Ÿ���� ȭ�� �ȿ� ���� ��
                if (indicatorPosition.z >= 0f)
                {
                    if (indicatorPosition.x <= screenSize.x + screenSize.width && indicatorPosition.x >= screenSize.x
                       && indicatorPosition.y <= screenSize.y + screenSize.height && indicatorPosition.y >= screenSize.y)
                    {
                        otherImg.enabled = false;
                        indicatorPosition.z = 0f;
                    }
                    else
                    {
                        otherImg.enabled = true;
                        indicatorPosition = OutOfRange(indicatorPosition);
                    }
                }
                //Ÿ���� �� ī�޶� �ڿ� ���� ��, ȭ�鿡 �׸�
                else
                {
                    imgTransform.sizeDelta = new Vector2(otherIndicatorNormal.bounds.size.x, otherIndicatorNormal.bounds.size.y);
                    otherImg.enabled = true;
                    SetSreenInfo();
                    indicatorPosition *= -1f;
                    indicatorPosition = OutOfRange(indicatorPosition);
                }
            }            
            // ž���϶�
            else
            {
                myImg.enabled = true;
                otherImg.enabled = true;
                imgTransform.sizeDelta = new Vector2(otherIndicatorTop.bounds.size.x, otherIndicatorTop.bounds.size.y);
                otherImg.sprite = otherIndicatorTop;
                // ������ ����
                Vector3 myIndicatorPosition = mainCamera.WorldToScreenPoint(myTF.position);

                myImgTransform.position = myIndicatorPosition;
                imgTransform.position = indicatorPosition;

                // ���� ����
                // �÷��̾��� Rotation.y���� UI�� Rotation.z���� �����Ǿ����.

                float myCurEulerY = myTF.rotation.eulerAngles.y > 180 ? myTF.rotation.eulerAngles.y - 360 :
                    (myTF.rotation.eulerAngles.y < -180 ? myTF.rotation.eulerAngles.y + 360 : myTF.rotation.eulerAngles.y);

                float otherCurEulerY = target.rotation.eulerAngles.y > 180 ? target.rotation.eulerAngles.y - 360 :
                    (target.rotation.eulerAngles.y < -180 ? target.rotation.eulerAngles.y + 360 : target.rotation.eulerAngles.y);

                // �׳� ���ʹϾ����� ������ �� �ȵǴ��� �˾Ƴ�����.
                myImgTransform.rotation = Quaternion.Euler(0, 0, -myCurEulerY);
                imgTransform.rotation = Quaternion.Euler(0, 0, -otherCurEulerY);
            }
            imgTransform.position = indicatorPosition;
        }
    }
}

